Scorecenter
===========

the app has been deployed at http://shielded-sands-3035.herokuapp.com/
Everything works according to spec. to the best of my knowledge